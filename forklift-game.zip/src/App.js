import React from 'react';
import ForkliftGame from './ForkliftGame';

export default function App() {
  return (
    <div className="container">
      <div className="card">
        <h1>Warehouse Forklift Driving Game</h1>
        <p>Use the Arrow Keys to drive the forklift and collect pallets.</p>
        <ForkliftGame />
        <p style={{marginTop:12}}>Tip: Add this to your Home Screen to install the app.</p>
      </div>
    </div>
  );
}
