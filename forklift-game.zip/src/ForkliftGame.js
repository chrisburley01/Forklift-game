import React, { useState, useEffect, useRef } from 'react';

export default function ForkliftGame() {
  const width = 800;
  const height = 500;
  const [forklift, setForklift] = useState({ x: 80, y: 80, angle: 0 });
  const [score, setScore] = useState(0);
  const [pallets, setPallets] = useState([
    { id: 1, x: 200, y: 150, collected: false },
    { id: 2, x: 350, y: 300, collected: false },
    { id: 3, x: 520, y: 220, collected: false },
    { id: 4, x: 700, y: 120, collected: false }
  ]);
  const speed = 4;
  const turnSpeed = 4;
  const size = { w: 40, h: 20 };
  const keysRef = useRef({});

  useEffect(() => {
    const down = (e) => { keysRef.current[e.key] = true; };
    const up = (e) => { keysRef.current[e.key] = false; };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    const loop = setInterval(() => {
      setForklift((prev) => {
        let { x, y, angle } = prev;
        if (keysRef.current['ArrowLeft']) angle -= turnSpeed;
        if (keysRef.current['ArrowRight']) angle += turnSpeed;
        const rad = angle * Math.PI / 180;
        if (keysRef.current['ArrowUp']) {
          x += speed * Math.cos(rad);
          y += speed * Math.sin(rad);
        }
        if (keysRef.current['ArrowDown']) {
          x -= speed * Math.cos(rad);
          y -= speed * Math.sin(rad);
        }
        // bounds
        x = Math.max(0, Math.min(width - size.w, x));
        y = Math.max(0, Math.min(height - size.h, y));
        return { x, y, angle };
      });
    }, 16);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      clearInterval(loop);
    };
  }, []);

  useEffect(() => {
    // Pallet collection
    const updated = pallets.map((p) => {
      const dx = (p.x - forklift.x);
      const dy = (p.y - forklift.y);
      if (!p.collected && Math.hypot(dx, dy) < 30) {
        setScore((s) => s + 1);
        return { ...p, collected: true };
      }
      return p;
    });
    setPallets(updated);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [forklift.x, forklift.y]);

  const reset = () => {
    setForklift({ x: 80, y: 80, angle: 0 });
    setScore(0);
    setPallets(pallets.map((p, i) => ({ ...p, collected: false })));
  };

  return (
    <div>
      <div style={{ marginBottom: 8 }}>Score: {score} / {pallets.length}</div>
      <div style={{
        position: 'relative',
        width: width + 'px',
        height: height + 'px',
        background: '#374151',
        border: '2px solid #6b7280',
        overflow: 'hidden',
        borderRadius: '12px'
      }}>
        {/* Walls */}
        <div style={{position:'absolute', left:0, top:0, width:'100%', height:'10px', background:'#111827'}}/>
        <div style={{position:'absolute', left:0, bottom:0, width:'100%', height:'10px', background:'#111827'}}/>
        <div style={{position:'absolute', top:0, left:0, width:'10px', height:'100%', background:'#111827'}}/>
        <div style={{position:'absolute', top:0, right:0, width:'10px', height:'100%', background:'#111827'}}/>

        {/* Forklift */}
        <div style={{
          position: 'absolute',
          left: forklift.x,
          top: forklift.y,
          width: size.w + 'px',
          height: size.h + 'px',
          background: '#facc15',
          transform: `rotate(${forklift.angle}deg)`,
          transformOrigin: 'center',
          borderRadius: '4px',
          boxShadow: '0 2px 8px rgba(0,0,0,.4)'
        }}/>

        {/* Pallets */}
        {pallets.map((p) => !p.collected && (
          <div key={p.id} style={{
            position: 'absolute',
            left: p.x,
            top: p.y,
            width: '30px',
            height: '30px',
            background: '#92400e',
            border: '2px solid #b45309',
            borderRadius: '4px',
            boxShadow: '0 2px 6px rgba(0,0,0,.3)'
          }}/>
        ))}
      </div>
      <button className='button' style={{marginTop:12}} onClick={reset}>Reset</button>
    </div>
  );
}
