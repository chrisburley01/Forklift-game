import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// Register simple SW for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/forklift-game/service-worker.js');
  });
}

const root = createRoot(document.getElementById('root'));
root.render(<App />);

reportWebVitals();
